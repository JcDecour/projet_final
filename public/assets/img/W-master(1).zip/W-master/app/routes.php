<?php
	
	$w_routes = array(
		['GET', '/', 'Default#home', 'default_home'],
	);