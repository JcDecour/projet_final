###Répertoire app/

Ce répertoire contient le code PHP *spécifique à votre application*. 

C'est ici que vous définissez vos contrôleurs, vos gestionnaires, vos fichiers de vue et votre configuration. 

3 fichiers de configuration y sont donc présents : 

* config.php : le fichier principal, où vous devez configurer votre application
* config.dist.php : le fichier à versionner et à partager, sans données sensibles ou persos.
* routes.php : contient toutes vos routes